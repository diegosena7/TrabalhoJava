package TestaMapa;

import java.util.HashMap;
import java.util.Map;

import br.com.rd.rdevs.conta.Conta;
import br.com.rd.rdevs.conta.ContaCorrente;

public class TestaMapa {
	public static void main(String[] args) {
		Conta c1 = new ContaCorrente();
			c1.depositar(10000);
		Conta c2 = new ContaCorrente();
			c2.depositar(3000);
		
		Map<String, Conta> mapaDeContas = new HashMap<String, Conta>();
		
			mapaDeContas.put("diretor", c1);
			mapaDeContas.put("gerente", c2);
		
		Conta contaDoDiretor = mapaDeContas.get("diretor");
		System.out.println(contaDoDiretor.getSaldo());
	}

}
//Usei a op��o add type arguments to "HashMap" em seguida a op��o add type arguments to "Map".