module Banco {
	requires java.desktop;
}