package br.com.rd.rdevs.main;

import br.com.rd.rdevs.conta.Conta;
import br.com.rd.rdevs.conta.ContaCorrente;

public class TestaArrays {
	
	public static void main(String[] args) {
			
		Conta[] contas = new Conta[10];
		
		for (int i = 0; i < contas.length; i++) {
			 contas[i] = new ContaCorrente();//Array criando conta (new ContaCorrente)
			 contas[i].depositar(i * 100);
		}
		
		double soma = 0.0;
		for (Conta x : contas) {
			soma += x.getSaldo();//Atribuindo saldo a vari�vel x
			System.out.println(soma);
		}
		double mediaSaldo = soma / contas.length;
		System.out.println("A m�dia �: " + mediaSaldo);
	}
	
}
/*
1. Crie uma classe TestaArrays e no m�todo main crie um array de contas de tamanho 10. Em seguida, 
fa�a um la�o para criar 10 contas com saldos distintos e coloc�-las no array. Por exemplo, voc� pode 
utilizar o �ndice do la�o e multiplic�-lo por 100 para gerar o saldo de cada conta:
	
	Conta[] contas = new Conta[10];
	for (int i = 0; i < contas.length; i++) {
		Conta conta = new ContaCorrente();
		conta.deposita(i * 100.0);
	}

2. Ainda na classe TestaArrays , fa�a um outro la�o para calcular e imprimir a m�dia dos saldos de todas as
contas do array.
*/