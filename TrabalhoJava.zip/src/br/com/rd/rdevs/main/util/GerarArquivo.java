package br.com.rd.rdevs.main.util;

public class GerarArquivo extends Thread{
		public void executar(){
			
		}

	}
