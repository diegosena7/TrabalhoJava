package br.com.rd.rdevs.main.util;

public class BarraDeProgresso extends Thread{
	public void executar(){
		
	}
}
