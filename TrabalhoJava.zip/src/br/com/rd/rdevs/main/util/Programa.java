package br.com.rd.rdevs.main.util;

public class Programa implements Runnable{

	private int identificador = 0;
	
	@Override
	public void run() {
		for(int i = 0; i < 10000; i++) {
			
		}
	}

	public int getIdentificador() {
		return identificador;
	}

	public void setIdentificador(int identificador) {
		this.identificador = identificador;
	}
}
