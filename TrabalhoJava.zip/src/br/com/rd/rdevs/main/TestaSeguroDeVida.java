package br.com.rd.rdevs.main;

import br.com.rd.rdevs.conta.ManipuladorDeSeguroDeVida;

public class TestaSeguroDeVida {
	
	public static void main(String[] args){
		
		ManipuladorDeSeguroDeVida seguroTotal = new ManipuladorDeSeguroDeVida();
		seguroTotal.criaSeguro(137, "Diego Sena", 167.00);
		
		ManipuladorDeSeguroDeVida seguroEspecial = new ManipuladorDeSeguroDeVida();
		seguroEspecial.criaSeguro(138, "Nayara Andrade", 175.00);
		
		seguroTotal.exibirDados();
		seguroEspecial.exibirDados();
	}

}
