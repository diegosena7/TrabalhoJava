package br.com.rd.rdevs.main;

public class TestaSeguroDeVidas {

}
