package br.com.rd.rdevs.main;

import br.com.rd.rdevs.model.Gerente;

public class TestaFuncionario {
		public static void main(String [] args) {
			Gerente desenvolvedor = new Gerente("Diego", "3783787397333", 5000, "909090");
			desenvolvedor.getNome();
			desenvolvedor.getCpf();
			desenvolvedor.getBonificacao();
			System.out.println("Nome " + desenvolvedor.getNome() + "\nCpf: " + "\nSalario: " + desenvolvedor.getSalario());
		}
	
}
