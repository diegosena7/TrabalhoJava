package br.com.rd.rdevs.main;

import br.com.rd.rdevs.conta.Conta;
import br.com.rd.rdevs.conta.ContaCorrente;
import br.com.rd.rdevs.conta.SaldoInsuficienteException;

public class TestaConta {

	public static void main(String[] args) {
		
		try {
		Conta contaP = new ContaCorrente();
		contaP.depositar(100.0);
		contaP.sacar(200.0);
		}catch (IllegalArgumentException e){
            System.out.println(e.getMessage());
        }catch (SaldoInsuficienteException e){
            System.out.println(e.getMessage());
        }
	}
}
