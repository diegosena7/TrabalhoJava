package br.com.rd.rdevs.model;

public interface Tributavel {//Interface implementada
	public double getValorImposto();
}
