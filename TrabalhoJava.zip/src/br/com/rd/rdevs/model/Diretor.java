package br.com.rd.rdevs.model;

public class Diretor extends Funcionario{
	
	public Diretor(String nome, String cpf, int salario) {
		super(nome, cpf, salario);
	}
	private int ferias;
	private float pagamentos;
	private int contratar;
	
	
	//M�todos da classe
	
	public int getFerias() {
		return ferias;
	}
	public void setFerias(int ferias) {
		this.ferias = ferias;
	}
	public float getPagamentos() {
		return pagamentos;
	}
	public void setPagamentos(float pagamentos) {
		this.pagamentos = pagamentos;
	}
	public int getContratar() {
		return contratar;
	}
	public void setContratar(int contratar) {
		this.contratar = contratar;
	}
	@Override//Sobrescrita do m�todo
	public double bonificacao() {
		
		return salario * 1.2 + 600;
	}
}
