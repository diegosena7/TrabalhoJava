package br.com.rd.rdevs.model;

public class SeguroDeVida implements Tributavel{//Implementando a interface Tributavel na classe
	
	private double valorSeguro;
	private double taxaFixa = 42;
	private int numeroApolice;
	private String titular;
	private double valor;
	
	@Override
	public double getValorImposto() {
		return getValorSeguro() + taxaFixa + 0.02;//C�lculo de retorno do valor do seguro
	}

	public double getValorSeguro() {
		return valorSeguro;
	}

	public void setValorSeguro(double valorSeguro) {
		this.valorSeguro = valorSeguro;
	}

	public int getNumeroApolice() {
		return numeroApolice;
	}

	public void setNumeroApolice(int numeroApolice) {
		this.numeroApolice = numeroApolice;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public String getTitular() {
		return titular;
	}

	public void setTitular(String titular) {
		this.titular = titular;
	}

}
