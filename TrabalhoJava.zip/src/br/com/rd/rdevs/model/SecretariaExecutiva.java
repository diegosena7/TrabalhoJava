package br.com.rd.rdevs.model;

public class SecretariaExecutiva extends Secretaria {

	public SecretariaExecutiva(String nome, String cpf, int salario) {
		super(nome, cpf, salario);
	}

	@Override//Sobrescrita do m�todo
	public double bonificacao() {
		return 0;
	}
}
