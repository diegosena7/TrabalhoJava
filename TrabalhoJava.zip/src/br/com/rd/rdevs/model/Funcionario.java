package br.com.rd.rdevs.model;

public abstract class Funcionario {
	
	public String nome;
	protected String cpf;
	protected int salario;
	private int senha;

	
	
	public Funcionario(String nome, String cpf, int salario) {
		this.nome = nome;
		this.cpf = cpf;
		this.salario = salario;
	}
	
	
	public double calculoBonificacao() {//C�lculo bonifica��o funcion�rio
		return this.salario * 0.10;//Dessa forma n�o funciona, pois n�o h� base para c�lculo na var salario.
	}
	
	public abstract double bonificacao();//M�todo Abstrato
	
	//Jeito certo de inserir a bonifica��o, com o get estamos recebendo o valor de salario para calcular 
	public double getBonificacao() {
		return this.salario * 0.10;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	


	public int getSenha() {
		return senha;
	}


	public void setSenha(int senha) {
		this.senha = senha;
	}

}