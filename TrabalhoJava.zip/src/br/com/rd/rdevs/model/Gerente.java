package br.com.rd.rdevs.model;
	
	public class Gerente extends Funcionario {

		public Gerente(String nome, String cpf, int salario, String string) {
			super(nome, cpf, salario);
			// TODO Auto-generated constructor stub
		}
		
		protected int salario;
		public void Funcionario(String nome, String cpf, int salario) {
			this.nome = nome;
			this.cpf = cpf;
			this.salario = salario;
		}
		private int numeroDeFuncionariosGerenciados;
		public void getFuncionario() {
			
		}


		public int getNumeroDeFuncionariosGerenciados() {
			return numeroDeFuncionariosGerenciados;
		}

		public void setNumeroDeFuncionariosGerenciados(int numeroDeFuncionariosGerenciados) {
			this.numeroDeFuncionariosGerenciados = numeroDeFuncionariosGerenciados;
		}

		@Override
		public double bonificacao() {
			return salario * 1.15 + 500;
		}


		public String getSalario() {
			// TODO Auto-generated method stub
			return null;
		}
		
	}

