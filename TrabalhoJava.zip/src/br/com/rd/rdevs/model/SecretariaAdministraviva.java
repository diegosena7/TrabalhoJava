package br.com.rd.rdevs.model;

public class SecretariaAdministraviva extends Secretaria{

	public SecretariaAdministraviva(String nome, String cpf, int salario) {
		super(nome, cpf, salario);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double bonificacao() {
		// TODO Auto-generated method stub
		return 0;
	}
}
