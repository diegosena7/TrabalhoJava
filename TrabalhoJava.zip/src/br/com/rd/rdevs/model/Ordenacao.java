package br.com.rd.rdevs.model;

public class Ordenacao {

}
