package br.com.rd.rdevs.model;

public abstract class Secretaria extends Funcionario{

	public Secretaria(String nome, String cpf, int salario) {//M�todo construtor da Classe
		super(nome, cpf, salario);
	}
	

	}

