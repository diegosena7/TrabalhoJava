package br.com.rd.rdevs.model;

public class Presidente extends Diretor {
	public Presidente(String nome, String cpf, int salario) {//M�todo construtor da Classe
		super(nome, cpf, salario);
		// TODO Auto-generated constructor stub
	}

	public boolean dirigirEmpresa;
	public boolean comunicacaoColaboradores;
	
	public double calculoBonificacao() {//C�lculo bonifica��o funcion�rio
		return this.salario * 0.10;//Dessa forma n�o funciona, pois n�o h� base para c�lculo na var salario.
	}

	//Jeito certo de inserir a bonifica��o, com o get estamos recebendo o valor de salario para calcular 
		public double getBonificacao() {
		return this.salario * 1.15;
}
}