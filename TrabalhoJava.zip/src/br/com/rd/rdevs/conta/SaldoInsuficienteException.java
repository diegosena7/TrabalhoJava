package br.com.rd.rdevs.conta;

public class SaldoInsuficienteException extends RuntimeException{
	private static final long serialVersionUID = 1L;

	public SaldoInsuficienteException(double valorSacado) {
		super("Seu saldo � insuficiente, contate o gerente da sua conta!!!");
	}

}
