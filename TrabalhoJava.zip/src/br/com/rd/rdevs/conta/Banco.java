package br.com.rd.rdevs.conta;

import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Banco {
	List<Conta> contas;
	Map<String, Conta> buscaContas;
	private Object buscaTitular;
	
	public Banco() {
		this.contas = new ArrayList<Conta>();
		buscaContas = new HashMap();
	}	
public void adiciona(Conta conta) {
	this.contas.add(conta);
	this.buscaContas.put(conta.getTitular(), conta);
}
	public Conta pega(int i) {
		return ((Map<String, Conta>) this.contas).get(i);
	}
	public int qtidadeContas() {
		return this.contas.size();
	}
	public Conta buscaTitular(String nome) {
		return this.buscaContas.get(nome);
	}
}
