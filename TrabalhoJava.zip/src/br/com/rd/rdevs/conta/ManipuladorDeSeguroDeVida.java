package br.com.rd.rdevs.conta;

import br.com.rd.rdevs.model.SeguroDeVida;

public class ManipuladorDeSeguroDeVida {
	
	private SeguroDeVida seguroDeVida;
	
	
	public void criaSeguro(int numeroApolice, String titular, double valor){
		this.seguroDeVida = new SeguroDeVida();
		this.seguroDeVida.setNumeroApolice(numeroApolice);
		this.seguroDeVida.setValorSeguro(valor);
		this.seguroDeVida.setTitular(titular);
	}
	
	public void exibirDados() {
		System.out.println("N�mero de ap�lice: " + seguroDeVida.getNumeroApolice());
		System.out.println("O nome do titular �: " + seguroDeVida.getTitular());
		System.out.println("O valor da ap�lice �: " + seguroDeVida.getNumeroApolice());
	}
}
