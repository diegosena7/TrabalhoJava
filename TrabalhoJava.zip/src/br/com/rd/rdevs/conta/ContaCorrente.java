package br.com.rd.rdevs.conta;

import br.com.rd.rdevs.model.Tributavel;

public class ContaCorrente extends Conta implements Tributavel {
	
	private String tipoConta;

	public ContaCorrente(int numero, int agencia, String titular, double saldo, double limite, String dtAbertura,
			int identificador, String tipoConta) {
		super(numero, agencia, titular, saldo, limite, dtAbertura, identificador, tipoConta);
		// TODO Auto-generated constructor stub
	}
	
	public ContaCorrente() {
		
	}
	@Override
	public void sacar(double valorSacado) {
		if (valorSacado < 0){//Implementando a exce��o
			throw new IllegalArgumentException("N�o � poss�vel sacar um valor negativo!!");
		}else if(valorSacado > this.getSaldo()) {
			throw new SaldoInsuficienteException(valorSacado);
		}else {
			this.saldo -= valorSacado;
		}
	}

	@Override
	public String getTipoConta() {
		return tipoConta;
	}

	@Override
	public double getValorImposto() {
		return getSaldo()*0.01;//C�lculo de pagamento de 1% do valor do saldo
	}

	@Override
	public int compareTo(ContaCorrente o) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int compareTo(Conta o) {
		// TODO Auto-generated method stub
		return 0;
	}
}