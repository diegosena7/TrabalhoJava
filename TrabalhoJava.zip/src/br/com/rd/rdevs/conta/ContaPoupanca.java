package br.com.rd.rdevs.conta;

public class ContaPoupanca extends Conta {
	
	

	public ContaPoupanca(int numero, int agencia, String titular, double saldo, double limite, String dtAbertura,
			int identificador, String tipoConta) {
		super(numero, agencia, titular, saldo, limite, dtAbertura, identificador, tipoConta);
		// TODO Auto-generated constructor stub
	}

	public String tipo = "Poupanca";
	public String nome = "Diego Sena";
	protected float saldo = 1500.0f;
	
	public String getTipo() {
	return this.tipo;
	}
	
	public float sacarSalario(double quantiaASacar) {
		return saldo -= saldo - 0.10;
	}
		
		public float transferirValor(double quantiaATransferir) {
			return saldo -= saldo - quantiaATransferir;
	}

		@Override
		public String getTipoConta() {
			return this.tipo;
		}
}
