package br.com.rd.rdevs.conta;

public abstract class Conta implements Comparable<Conta>{
	//Atributos 
	private int numero;
    private int agencia;
	private String titular;
	protected double saldo;
    private double limite;
	private String dtAbertura;
	private static int identificador;
	private String tipoConta;
	private static int qtidadeContas = 0;
	private double rendimento;
	
	

	@Override
    public int compareTo(Conta ContaCorrente) {
        return this.titular.compareTo(ContaCorrente.getTitular());
    }
	
	public Conta() {
		
	}
	
	public Conta(int numero, int agencia, String titular, double saldo, double limite, String dtAbertura,
			int identificador, String tipoConta) {
		identificador++;
		  
	}

	//M�todos
	public void sacar(double valorSacado) {
        if (this.saldo < valorSacado && valorSacado < 0) {
            
        } else {
            this.saldo = this.saldo - valorSacado;
            
        }
	}
		
	
	
	public void depositar(double valorDepositado){
        if (valorDepositado < 0){//Implementando a exce��o
			throw new IllegalArgumentException("O valor � negavito, favor verificar!!!");
		}else{
            this.saldo += valorDepositado;
            setRendimento(0.10);
		}	
	}

	public boolean transferir(Conta destino, double valorTransferido){
		if (this.saldo >= valorTransferido){
			this.saldo -= valorTransferido;
			return true;
		}else{
			return false;
		}
    }
    
    // boolean calcularRendimento() {
    //     double rendimento = 0.10;
    //     this.saldo *= rendimento;
    //     return true;
    // }


    void recuperarDadosParaImpressao() {
        System.out.println("Conta:" + this.numero);
        System.out.println("Agencia: " + this.agencia);
        System.out.println("Titular: " + this.titular);
        System.out.println("Data de Abertura: " + this.dtAbertura);
        System.out.println("Saldo dispon�vel: " + this.saldo);
        System.out.println("Tipo de Conta: " + this.tipoConta);

	}
	

	public String getTitular (){
		return titular;
	}

	public int getNumero(){
		return numero;
	}

	public int getAgencia(){
		return agencia;
	}

	public double getSaldo (){
		return saldo;
	}

	public double getLimite (){
		return limite;
	}

	public void setLimite (double limite){
		this.limite = limite;
	}

	public String getDtAbertura(){
		return dtAbertura;
	}

	public int getIdentificador(){
		return Conta.identificador;
	}
	
	public abstract String getTipoConta();//M�todo transformado em abstrato 
		
	public void setTipoConta(String tipoConta) {
		this.tipoConta = tipoConta;
	}

	public void ContaBancaria(int numero, int agencia, String titular, double saldo, double limite, String dtAbertura,
			int identificador, String tipoConta) {
		this.numero = numero;
		this.agencia = agencia;
		this.titular = titular;
		this.saldo = saldo;
		this.limite = limite;
		this.dtAbertura = dtAbertura;
		this.tipoConta = tipoConta;
	}

	public static int getQtidadeContas() {
		return qtidadeContas;
	}

	public static void setQtidadeContas(int qtidadeContas) {
		Conta.qtidadeContas = qtidadeContas;
	}

	public int compareTo(ContaCorrente o) {
		
		return 0;
	}

	public double getRendimento() {
		return rendimento;
	}

	public void setRendimento(double rendimento) {
		this.rendimento = rendimento;
	}
}
	

