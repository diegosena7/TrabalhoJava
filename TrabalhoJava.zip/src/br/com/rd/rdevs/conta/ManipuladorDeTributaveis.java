package br.com.rd.rdevs.conta;

public class ManipuladorDeTributaveis {

	public void calculaImposto() {
	}
}
