package JavaLang;
//Fazer testes executando atrav�s do m�todo main
public class TesteLang {
	public static void main(String[] args) {
		
		Lang lang1 = new Lang();
			
		lang1.inverter("7890");

		System.out.println(lang1.inverter("789021"));
		lang1.setFrase("Diego Sena");
		System.out.println(lang1.inverter(lang1.getFrase()));
	}
}
