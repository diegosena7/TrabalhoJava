package JavaLang;

public class Lang {

	String frase;
	
	public Lang() {//Construtor
		
	}

	public String getFrase() {
		return frase;
	}

	public void setFrase(String frase) {
		this.frase = frase;
	}
	
	public String inverter(String frase) {
		String retornoFrase = "";
		
		for(int i = (frase.length()-1); i >=0; i--) {
			retornoFrase += frase.charAt(i);
		}
			
		return retornoFrase;
	}
	
	
}
