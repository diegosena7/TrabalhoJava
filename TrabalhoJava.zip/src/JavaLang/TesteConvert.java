package JavaLang;

public class TesteConvert {
public static void main(String[] args) {//Converta uma String para um n�mero
	
	ConvertString teste = new ConvertString();
	ConvertString teste1 = new ConvertString();
	
	teste.setPalavra("0909");
	
	System.out.println(teste.getPalavra() +1);
	System.out.println(teste1.converter("7")+2);
	
}
}
