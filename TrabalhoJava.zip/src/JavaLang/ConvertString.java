package JavaLang;

public class ConvertString {

	private String palavra;
	
	public ConvertString() {
		
	}
	
	public int converter(String palavra) {
		int numero;
		numero = Integer.parseInt(palavra);
		return numero;
	}

	public String getPalavra() {
		return palavra;
	}

	public void setPalavra(String palavra) {
		this.palavra = palavra;
	}
}
